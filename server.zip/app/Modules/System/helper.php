<?php
 /**
 *	System Helper  
 */