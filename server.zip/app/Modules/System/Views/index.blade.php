<?php

echo trans('System::example.welcome');