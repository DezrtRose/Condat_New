<?php
 /**
 *	Dashboard Helper
 */