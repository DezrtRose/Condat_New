<?php

namespace App\Condat\Facades;


class CurrentUser {

}