<?php

echo trans('Frontend::example.welcome');