<?php namespace App\Modules\Frontend\Models;

use Illuminate\Database\Eloquent\Model;

class Frontend extends Model {

	//

}
