<?php
 /**
 *	User Helper  
 */