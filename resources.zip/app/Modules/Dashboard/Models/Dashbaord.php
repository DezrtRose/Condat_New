<?php namespace App\Modules\Dashboard\Models;

use Illuminate\Database\Eloquent\Model;

class Dashboard extends Model {

	//

}
