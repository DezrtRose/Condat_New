<?php
 /**
 *	Auth Helper  
 */