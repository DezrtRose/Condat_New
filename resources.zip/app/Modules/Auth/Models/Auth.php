<?php namespace App\Modules\Auth\Models;

use Illuminate\Database\Eloquent\Model;

class Auth extends Model {

	//

}
