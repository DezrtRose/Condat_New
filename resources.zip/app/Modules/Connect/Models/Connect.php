<?php namespace App\Modules\Connect\Models;

use Illuminate\Database\Eloquent\Model;

class Connect extends Model {

	//

}
