<?php
 /**
 *	Connect Helper  
 */