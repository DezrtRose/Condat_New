<?php
 /**
 *	Tenant/client Helper  
 */