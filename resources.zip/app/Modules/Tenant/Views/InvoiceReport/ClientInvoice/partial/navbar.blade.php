<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300' rel='stylesheet' type='text/css'>
<nav class="nav-bar">
  <div class="nav-container">
    <a id="nav-menu" class="nav-menu">&#9776; Menu</a>
    <ul class="nav-list " id="nav">
      <li> <a href="#" id="tile1" class="text-uppercase"> Client Invoices</a></li>
      <li class="{{ Request::is('tenant/client_invoice_report/invoice_pending') ? 'active' : '' }}"> <a href="{{ route('client.invoice.pending') }}" id="tile2"><i class="fa fa-hourglass-half"></i> Pending Invoices</a></li>
      <li class="{{ Request::is('tenant/client_invoice_report/invoice_paid') ? 'active' : '' }}"> <a href="{{ route('client.invoice.paid') }}" id="tile3"><i class="fa fa-money"></i> Paid Invoices</a></li>
      <li class="{{ Request::is('tenant/client_invoice_report/invoice_future') ? 'active' : '' }}"> <a href="{{ route('client.invoice.future') }}" id="tile4"><i class="glyphicon glyphicon-piggy-bank"></i> Future Invoices</a></li>
      <li class="{{ Request::is('tenant/client_invoice_report/search') ? 'active' : '' }}"> <a href="{{ route('client.invoice.search') }}" id="tile5"><i class="fa fa-search-plus"></i> Advance Search</a></li>
    </ul>
  </div>
</nav>