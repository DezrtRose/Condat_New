# Bar Chart
Bar chart built with HTML5, CSS, Javascript, and JQuery
